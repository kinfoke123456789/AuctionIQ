using System;
using System.Collections.Generic;

namespace AuctionApp.Shared.Models
{
    public class Auction
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal StartingPrice { get; set; }
        public decimal CurrentBid { get; set; }
        public string SellerId { get; set; }
        public string HighestBidderId { get; set; }
        public DateTime EndTime { get; set; }
        public List<Bid> Bids { get; set; } = new();
    }

    public class Bid
    {
        public string UserId { get; set; }
        public decimal Amount { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
