using Microsoft.Azure.Cosmos;
using AuctionApp.Shared.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class AuctionRepository
{
    private readonly Container _container;

    public AuctionRepository(CosmosClient client)
    {
        _container = client.GetContainer("AuctionDB", "Auctions");
    }

    public async Task<List<Auction>> GetAllAuctionsAsync() =>
        (await _container.GetItemQueryIterator<Auction>("SELECT * FROM c").ReadNextAsync()).ToList();

    public async Task AddAuctionAsync(Auction auction) =>
        await _container.CreateItemAsync(auction, new PartitionKey(auction.Id));

    public async Task UpdateAuctionAsync(Auction auction) =>
        await _container.ReplaceItemAsync(auction, auction.Id, new PartitionKey(auction.Id));
}
