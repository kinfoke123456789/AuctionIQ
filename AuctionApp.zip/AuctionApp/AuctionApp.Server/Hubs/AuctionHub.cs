using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

public class AuctionHub : Hub
{
    public async Task PlaceBid(string auctionId, string userId, decimal amount)
    {
        await Clients.All.SendAsync("ReceiveBid", auctionId, userId, amount);
    }
}
