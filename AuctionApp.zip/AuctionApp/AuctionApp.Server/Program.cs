app.MapHub<AuctionHub>("/auctionHub");
